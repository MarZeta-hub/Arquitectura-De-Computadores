echo Compilando el archivo practica.cpp
g++ -std=c++17 -Wall -Wextra -Wno-deprecated -Werror -pedantic -pedantic-errors -o practica practica.cpp
echo Completado